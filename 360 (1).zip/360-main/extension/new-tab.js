/* ══════════════════════
   THEME
══════════════════════ */
const themeBtn = document.getElementById("themeBtn");
let isDark = localStorage.getItem("360nt_dark") !== "false";

function applyTheme() {
  document.body.classList.toggle("light", !isDark);
  themeBtn.textContent = isDark ? "🌙" : "☀️";
}
applyTheme();

themeBtn.addEventListener("click", () => {
  isDark = !isDark;
  localStorage.setItem("360nt_dark", isDark);
  applyTheme();
});

/* ══════════════════════
   CLOCK
══════════════════════ */
const DAYS   = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];

function pad(n) { return String(n).padStart(2,"0"); }

function updateClock() {
  const now = new Date();
  const h = pad(now.getHours()), m = pad(now.getMinutes()), s = pad(now.getSeconds());
  document.getElementById("clock").textContent = `${h}:${m}:${s}`;
  document.getElementById("dateStr").textContent =
    `${DAYS[now.getDay()]}, ${MONTHS[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()}`;
  const hr = now.getHours();
  const g = hr < 12 ? "Good morning ☀️" : hr < 17 ? "Good afternoon 🌤️" : hr < 21 ? "Good evening 🌆" : "Good night 🌙";
  document.getElementById("greeting").textContent = g;
}
setInterval(updateClock, 1000);
updateClock();

/* ══════════════════════
   SEARCH
══════════════════════ */
function doSearch() {
  const q = document.getElementById("searchInput").value.trim();
  if (!q) return;
  window.location.href = `https://360-search.com/?q=${encodeURIComponent(q)}`;
}
document.getElementById("searchBtn").addEventListener("click", doSearch);
document.getElementById("searchInput").addEventListener("keydown", e => {
  if (e.key === "Enter") doSearch();
});

/* ══════════════════════
   WEATHER
══════════════════════ */
const WMO_ICONS = {
  0:"☀️",1:"🌤️",2:"⛅",3:"☁️",45:"🌫️",48:"🌫️",
  51:"🌦️",53:"🌧️",55:"🌧️",61:"🌧️",63:"🌧️",65:"🌧️",
  71:"❄️",73:"❄️",75:"❄️",80:"🌦️",81:"🌧️",82:"⛈️",
  95:"⛈️",96:"⛈️",99:"⛈️"
};
const WMO_DESC = {
  0:"Clear sky",1:"Mainly clear",2:"Partly cloudy",3:"Overcast",
  45:"Foggy",48:"Icy fog",51:"Light drizzle",53:"Drizzle",55:"Heavy drizzle",
  61:"Light rain",63:"Rain",65:"Heavy rain",71:"Light snow",73:"Snow",75:"Heavy snow",
  80:"Rain showers",81:"Heavy showers",82:"Violent showers",
  95:"Thunderstorm",96:"Thunderstorm w/ hail",99:"Thunderstorm w/ heavy hail"
};

async function loadWeather() {
  if (!navigator.geolocation) { document.getElementById("weatherDesc").textContent = "Geolocation not available"; return; }
  navigator.geolocation.getCurrentPosition(async pos => {
    const { latitude: lat, longitude: lon } = pos.coords;
    try {
      const [wRes, gRes] = await Promise.all([
        fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,weathercode,windspeed_10m,apparent_temperature&wind_speed_unit=mph`),
        fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json`)
      ]);
      const w = await wRes.json();
      const g = await gRes.json();
      const cur = w.current;
      const useFahrenheit = localStorage.getItem("360nt_unit") === "F";
      const tempC = cur.temperature_2m;
      const feelsC = cur.apparent_temperature;
      const displayTemp = useFahrenheit ? `${Math.round(tempC * 9/5 + 32)}°F` : `${Math.round(tempC)}°C`;
      const displayFeels = useFahrenheit ? `${Math.round(feelsC * 9/5 + 32)}°F` : `${Math.round(feelsC)}°C`;
      const code = cur.weathercode;
      const city = g.address?.city || g.address?.town || g.address?.village || "Your location";
      document.getElementById("weatherIcon").textContent = WMO_ICONS[code] || "🌡️";
      document.getElementById("weatherTemp").textContent = displayTemp;
      document.getElementById("weatherDesc").textContent = WMO_DESC[code] || "Unknown";
      document.getElementById("weatherLoc").textContent = `📍 ${city}`;
      document.getElementById("weatherExtra").innerHTML =
        `<div>💧 ${cur.relative_humidity_2m}%</div>
         <div>💨 ${Math.round(cur.windspeed_10m)} mph</div>
         <div>Feels ${displayFeels}</div>`;
      // click to toggle unit
      document.getElementById("weatherCard").style.cursor = "pointer";
      document.getElementById("weatherCard").addEventListener("click", () => {
        const u = localStorage.getItem("360nt_unit") === "F" ? "C" : "F";
        localStorage.setItem("360nt_unit", u);
        loadWeather();
      });
    } catch { document.getElementById("weatherDesc").textContent = "Weather unavailable"; }
  }, () => { document.getElementById("weatherDesc").textContent = "Location denied"; document.getElementById("weatherLoc").textContent = ""; });
}
loadWeather();

/* ══════════════════════
   QUICK LINKS
══════════════════════ */
const LINKS = [
  { icon:"🤖", label:"AI",         href:"https://360-search.com/ai.html" },
  { icon:"💬", label:"Chat",       href:"https://360-search.com/chat.html" },
  { icon:"📰", label:"News",       href:"https://360-search.com/news.html" },
  { icon:"🌦️", label:"Weather",    href:"https://360-search.com/weather.html" },
  { icon:"📈", label:"Stocks",     href:"https://360-search.com/stocks.html" },
  { icon:"🌍", label:"Translator", href:"https://360-search.com/translator.html" },
  { icon:"🔗", label:"Shorten",    href:"https://360-search.com/url-shortener.html" },
  { icon:"🎮", label:"Games",      href:"https://360-search.com/games.html" },
];

const linksGrid = document.getElementById("quickLinks");
LINKS.forEach(l => {
  const a = document.createElement("a");
  a.className = "link-item";
  a.href = l.href;
  a.innerHTML = `<div class="li-icon">${l.icon}</div><div>${l.label}</div>`;
  linksGrid.appendChild(a);
});

/* ══════════════════════
   APPS ROW
══════════════════════ */
const APPS = [
  { icon:"🔍", label:"Google",     href:"https://google.com" },
  { icon:"📺", label:"YouTube",    href:"https://youtube.com" },
  { icon:"📧", label:"Gmail",      href:"https://mail.google.com" },
  { icon:"📅", label:"Calendar",   href:"https://calendar.google.com" },
  { icon:"📁", label:"Drive",      href:"https://drive.google.com" },
  { icon:"𝕏",  label:"Twitter/X",  href:"https://x.com" },
  { icon:"📸", label:"Instagram",  href:"https://instagram.com" },
  { icon:"🎵", label:"Spotify",    href:"https://open.spotify.com" },
];

const appsRow = document.getElementById("appsRow");
APPS.forEach(a => {
  const el = document.createElement("a");
  el.className = "app-pill";
  el.href = a.href;
  el.innerHTML = `${a.icon} ${a.label}`;
  appsRow.appendChild(el);
});

/* ══════════════════════
   CALCULATOR
══════════════════════ */
let calcExprStr = "";
let calcCurrentVal = "0";
let calcJustEvaled = false;

const calcButtons = [
  { label:"C",   cls:"clr",   val:"C"   },
  { label:"±",   cls:"op",    val:"±"   },
  { label:"%",   cls:"op",    val:"%"   },
  { label:"÷",   cls:"op",    val:"/"   },
  { label:"7",   cls:"",      val:"7"   },
  { label:"8",   cls:"",      val:"8"   },
  { label:"9",   cls:"",      val:"9"   },
  { label:"×",   cls:"op",    val:"*"   },
  { label:"4",   cls:"",      val:"4"   },
  { label:"5",   cls:"",      val:"5"   },
  { label:"6",   cls:"",      val:"6"   },
  { label:"−",   cls:"op",    val:"-"   },
  { label:"1",   cls:"",      val:"1"   },
  { label:"2",   cls:"",      val:"2"   },
  { label:"3",   cls:"",      val:"3"   },
  { label:"+",   cls:"op",    val:"+"   },
  { label:"0",   cls:"span2", val:"0"   },
  { label:".",   cls:"",      val:"."   },
  { label:"=",   cls:"eq",    val:"="   },
];

function calcRender() {
  document.getElementById("calcExpr").textContent = calcExprStr;
  document.getElementById("calcVal").textContent  = calcCurrentVal;
}

function calcPress(val) {
  if (val === "C") {
    calcExprStr = "";
    calcCurrentVal = "0";
    calcJustEvaled = false;
    calcRender();
    return;
  }
  if (val === "±") {
    if (calcCurrentVal !== "0") calcCurrentVal = calcCurrentVal.startsWith("-") ? calcCurrentVal.slice(1) : "-" + calcCurrentVal;
    calcRender();
    return;
  }
  if (val === "%") {
    try { calcCurrentVal = String(parseFloat(calcCurrentVal) / 100); } catch{}
    calcRender();
    return;
  }
  if (val === "=") {
    const expr = calcExprStr + calcCurrentVal;
    calcExprStr = expr + " =";
    try {
      const result = Function('"use strict"; return (' + expr + ')')();
      calcCurrentVal = String(parseFloat(result.toFixed(10)));
    } catch { calcCurrentVal = "Error"; }
    calcJustEvaled = true;
    calcRender();
    return;
  }
  const isOp = ["+","-","*","/"].includes(val);
  if (isOp) {
    if (calcJustEvaled) { calcExprStr = calcCurrentVal; }
    else { calcExprStr += calcCurrentVal; }
    calcExprStr += " " + val + " ";
    calcCurrentVal = "0";
    calcJustEvaled = false;
  } else {
    if (calcJustEvaled) { calcCurrentVal = "0"; calcJustEvaled = false; }
    if (val === "." && calcCurrentVal.includes(".")) { calcRender(); return; }
    calcCurrentVal = calcCurrentVal === "0" && val !== "." ? val : calcCurrentVal + val;
  }
  calcRender();
}

const calcGrid = document.getElementById("calcGrid");
calcButtons.forEach(b => {
  const btn = document.createElement("button");
  btn.className = "calc-btn " + b.cls;
  btn.textContent = b.label;
  btn.addEventListener("click", () => calcPress(b.val));
  calcGrid.appendChild(btn);
});

/* Keyboard support */
document.addEventListener("keydown", e => {
  if (e.target.tagName === "INPUT") return;
  const map = {"0":"0","1":"1","2":"2","3":"3","4":"4","5":"5","6":"6","7":"7","8":"8","9":"9",
               "+":"+","-":"-","*":"*","/":"/",".":".","%":"%","Enter":"=","=":"=","Escape":"C","Backspace":"DEL"};
  if (e.key === "Backspace") {
    if (calcCurrentVal.length > 1) calcCurrentVal = calcCurrentVal.slice(0,-1);
    else calcCurrentVal = "0";
    calcRender();
    return;
  }
  if (map[e.key]) { e.preventDefault(); calcPress(map[e.key]); }
});

/* ══════════════════════
   TODO
══════════════════════ */
let todos = JSON.parse(localStorage.getItem("360nt_todos") || "[]");

function saveTodos() { localStorage.setItem("360nt_todos", JSON.stringify(todos)); }

function renderTodos() {
  const list = document.getElementById("todoList");
  list.innerHTML = "";
  if (!todos.length) {
    list.innerHTML = `<div class="todo-empty">Nothing here yet — add a task!</div>`;
    return;
  }
  todos.forEach((t, i) => {
    const item = document.createElement("div");
    item.className = "todo-item" + (t.done ? " done" : "");
    item.innerHTML = `
      <input type="checkbox" ${t.done ? "checked" : ""} data-i="${i}" />
      <span class="todo-text">${t.text}</span>
      <button class="todo-del" data-i="${i}">✕</button>
    `;
    list.appendChild(item);
  });
}

document.getElementById("todoList").addEventListener("click", e => {
  const i = parseInt(e.target.dataset.i);
  if (e.target.type === "checkbox") { todos[i].done = e.target.checked; saveTodos(); renderTodos(); }
  if (e.target.classList.contains("todo-del")) { todos.splice(i,1); saveTodos(); renderTodos(); }
});

function addTodo() {
  const inp = document.getElementById("todoInput");
  const text = inp.value.trim();
  if (!text) return;
  todos.unshift({ text, done: false });
  saveTodos();
  renderTodos();
  inp.value = "";
}

document.getElementById("todoAdd").addEventListener("click", addTodo);
document.getElementById("todoInput").addEventListener("keydown", e => { if (e.key === "Enter") addTodo(); });

renderTodos();

/* ══════════════════════
   QUOTES
══════════════════════ */
const QUOTES = [
  { text: "The secret of getting ahead is getting started.", author: "Mark Twain" },
  { text: "It does not matter how slowly you go as long as you do not stop.", author: "Confucius" },
  { text: "Build. Break. Learn. Repeat.", author: "Unknown" },
  { text: "Code is like humor. When you have to explain it, it's bad.", author: "Cory House" },
  { text: "Simplicity is the soul of efficiency.", author: "Austin Freeman" },
  { text: "Make it work, make it right, make it fast.", author: "Kent Beck" },
  { text: "Programs must be written for people to read.", author: "Harold Abelson" },
  { text: "Stay focused and never stop.", author: "360 Digital" },
  { text: "Every expert was once a beginner.", author: "Helen Hayes" },
  { text: "Dream big. Start small. Act now.", author: "Robin Sharma" },
];

(function loadQuote() {
  const q = QUOTES[Math.floor(Math.random() * QUOTES.length)];
  document.getElementById("quoteText").textContent = `"${q.text}"`;
  document.getElementById("quoteAuthor").textContent = `— ${q.author}`;
})();

/* ══════════════════════
   SUPPRESS CHROME NTP UI
══════════════════════ */
(function removeNtpUI() {
  const SELECTORS = ['ntp-app','#ntp-app','#customize-chrome-side-panel',
    'ntp-customize-dialog','ntp-realbox','ntp-most-visited','#ntp-footer','.ntp-footer'];
  function purge() {
    SELECTORS.forEach(sel => {
      document.querySelectorAll(sel).forEach(el => el.remove());
    });
  }
  purge();
  // Watch for Chrome injecting elements after load
  new MutationObserver(purge).observe(document.body, { childList: true, subtree: true });
})();
